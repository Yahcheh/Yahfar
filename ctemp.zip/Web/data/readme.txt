Put patch files in this directory.
You may change this location in the configuration file